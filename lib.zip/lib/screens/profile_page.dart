import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/auth_service.dart';
import 'otp_page.dart';
import '../theme/app_theme.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  static const _navy = Color(0xFF080F1E);
  static const _gold = Color(0xFFF5C518);

  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;
  final _authService = AuthService();
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();

  bool _isEditing = false;
  bool _isSaving = false;
  Map<String, dynamic> _userData = {};

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProfile() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    try {
      final doc = await _db.collection('users').doc(uid).get();
      if (doc.exists && mounted) {
        setState(() {
          _userData = doc.data() ?? {};
          _nameCtrl.text = _userData['name'] ?? '';
          _phoneCtrl.text = _userData['phone'] ?? '';
        });
      }
    } catch (_) {}
  }

  Future<void> _saveProfile() async {
    setState(() => _isSaving = true);
    try {
      final uid = _auth.currentUser?.uid;
      final newPhone = _phoneCtrl.text.trim();
      final oldPhone = _userData['phone'] ?? '';
      final phoneChanged = newPhone.isNotEmpty && newPhone != oldPhone;

      // Save name immediately
      await _authService.updateUserProfile(name: _nameCtrl.text.trim());
      if (uid != null) {
        await _db.collection('users').doc(uid).update({
          'name': _nameCtrl.text.trim(),
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }

      if (mounted) setState(() => _isEditing = false);

      // If phone changed → verify via OTP before saving
      if (phoneChanged) {
        if (!mounted) return;
        final formatted = newPhone.startsWith('+') ? newPhone : '+91$newPhone';
        setState(() => _isSaving = true);
        await AuthService().verifyPhoneNumber(
          phoneNumber: formatted,
          onCodeSent: (verificationId) {
            if (!mounted) return;
            setState(() => _isSaving = false);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => OtpPage(
                  phone: formatted,
                  verificationId: verificationId,
                  isPhoneUpdate: true,
                ),
              ),
            ).then((_) {
              // After OTP verified, save phone to Firestore
              if (uid != null) {
                _db.collection('users').doc(uid).update({
                  'phone': formatted,
                  'phoneVerified': true,
                  'updatedAt': FieldValue.serverTimestamp(),
                });
              }
              _loadProfile(); // Refresh
            });
          },
          onError: (error) {
            if (!mounted) return;
            setState(() => _isSaving = false);
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(error), backgroundColor: Colors.red),
            );
          },
          onAutoVerify: (user) {
            if (uid != null) {
              _db.collection('users').doc(uid).update({
                'phone': formatted,
                'phoneVerified': true,
                'updatedAt': FieldValue.serverTimestamp(),
              });
            }
            _loadProfile();
          },
        );
        return;
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Profile updated'),
            backgroundColor: Color(0xFF10B981),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: \$e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser;
    final initials = (_userData['name'] as String? ?? user?.displayName ?? 'U')
        .split(' ')
        .map((w) => w.isNotEmpty ? w[0] : '')
        .take(2)
        .join()
        .toUpperCase();

    return Scaffold(
      backgroundColor: AppColors.of(context).bg,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
        title: const Text(
          'My Profile',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
        ),
        elevation: 0,
        actions: [
          TextButton(
            onPressed: () => setState(() => _isEditing = !_isEditing),
            child: Text(
              _isEditing ? 'Cancel' : 'Edit',
              style: const TextStyle(
                color: _gold,
                fontWeight: FontWeight.w700,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // AVATAR
            Center(
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 52,
                    backgroundColor: _gold.withValues(alpha: 0.2),
                    backgroundImage: user?.photoURL != null
                        ? NetworkImage(user!.photoURL!)
                        : null,
                    child: user?.photoURL == null
                        ? Text(
                            initials,
                            style: const TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.w900,
                              color: _gold,
                            ),
                          )
                        : null,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            Text(
              _userData['name'] ?? user?.displayName ?? 'User',
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w900,
                color: _navy,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              user?.email ?? '',
              style: const TextStyle(fontSize: 13, color: Color(0xFF475569)),
            ),

            const SizedBox(height: 28),

            // EDIT FORM
            if (_isEditing) ...[
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.of(context).card,
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    )
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Edit Profile',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: _navy,
                      ),
                    ),
                    const SizedBox(height: 16),
                    _buildField(
                        _nameCtrl, 'Full Name', Icons.person_outline_rounded),
                    const SizedBox(height: 14),
                    _buildField(
                        _phoneCtrl, 'Phone Number', Icons.phone_outlined,
                        keyboard: TextInputType.phone),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _gold,
                          foregroundColor: _navy,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                          elevation: 0,
                        ),
                        onPressed: _isSaving ? null : _saveProfile,
                        child: _isSaving
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2, color: _navy),
                              )
                            : const Text(
                                'SAVE CHANGES',
                                style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.2),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ] else ...[
              // PROFILE DETAILS
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.of(context).card,
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    )
                  ],
                ),
                child: Column(
                  children: [
                    _infoRow(Icons.person_outline_rounded, 'Name',
                        _userData['name'] ?? user?.displayName ?? '-'),
                    const Divider(height: 20, color: Color(0xFFE8EDF5)),
                    _infoRow(Icons.email_outlined, 'Email', user?.email ?? '-'),
                    const Divider(height: 20, color: Color(0xFFE8EDF5)),
                    _infoRow(Icons.phone_outlined, 'Phone',
                        _userData['phone'] ?? '-'),
                    const Divider(height: 20, color: Color(0xFFE8EDF5)),
                    _infoRow(
                      Icons.verified_user_outlined,
                      'Email Verified',
                      user?.emailVerified ?? false
                          ? '✅ Verified'
                          : '⚠️ Not verified',
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // STATS
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.of(context).card,
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    )
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _statCol('Total Orders', '${_userData['totalOrders'] ?? 0}',
                        Icons.shopping_bag_rounded, _gold),
                    Container(
                        width: 1, height: 40, color: const Color(0xFFE8EDF5)),
                    _statCol(
                        'Loyalty Points',
                        '${_userData['loyaltyPoints'] ?? 0}',
                        Icons.stars_rounded,
                        const Color(0xFF8B5CF6)),
                    Container(
                        width: 1, height: 40, color: const Color(0xFFE8EDF5)),
                    _statCol(
                        'Total Spent',
                        '₹${((_userData['totalSpent'] ?? 0) as num).toStringAsFixed(0)}',
                        Icons.currency_rupee_rounded,
                        const Color(0xFF10B981)),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 20),

            // SIGN OUT BUTTON
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: Colors.red.withValues(alpha: 0.5)),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      title: const Text('Sign Out',
                          style: TextStyle(fontWeight: FontWeight.w800)),
                      content: const Text('Are you sure you want to sign out?'),
                      actions: [
                        TextButton(
                            onPressed: () => Navigator.pop(ctx, false),
                            child: const Text('Cancel')),
                        TextButton(
                          onPressed: () => Navigator.pop(ctx, true),
                          child: const Text('Sign Out',
                              style: TextStyle(color: Colors.red)),
                        ),
                      ],
                    ),
                  );
                  if (confirm == true && mounted) {
                    await _authService.signOut();
                  }
                },
                child: const Text(
                  'Sign Out',
                  style: TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildField(TextEditingController ctrl, String label, IconData icon,
      {TextInputType? keyboard}) {
    final t = AppColors.of(context);
    return TextField(
      controller: ctrl,
      keyboardType: keyboard,
      style: TextStyle(color: t.textHi, fontSize: 14),
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: const Color(0xFF94A3B8), size: 20),
        filled: true,
        fillColor: AppColors.of(context).input,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE8EDF5))),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE8EDF5))),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: _gold, width: 2)),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    final t = AppColors.of(context);
    return Row(
      children: [
        Icon(icon, size: 18, color: const Color(0xFF94A3B8)),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(
                      fontSize: 11, color: Color(0xFF94A3B8))),
              Text(value,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: t.textHi)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _statCol(String label, String value, IconData icon, Color color) =>
      Column(
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 6),
          Text(value,
              style: TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w900, color: color)),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(fontSize: 11, color: Color(0xFF475569))),
        ],
      );
}
