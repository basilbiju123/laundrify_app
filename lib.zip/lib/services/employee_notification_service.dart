// lib/services/employee_notification_service.dart
//
// Sends three simultaneous notifications when an employee is added:
//   1. In-app    → /notifications Firestore doc (visible in the app notification page)
//   2. Email     → EmailJS API (free, sends from your Gmail, no domain needed)
//   3. WhatsApp  → opens WhatsApp via wa.me with pre-filled message
//
// EmailJS setup:
//   1. Sign up free at https://www.emailjs.com
//   2. Add Email Service → connect your Gmail → copy the Service ID
//   3. Create Email Template → copy the Template ID
//   4. Go to Account → copy your Public Key
//   5. Fill in the three constants below

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class EmployeeNotificationService {
  static final EmployeeNotificationService _i =
      EmployeeNotificationService._internal();
  factory EmployeeNotificationService() => _i;
  EmployeeNotificationService._internal();

  final _db = FirebaseFirestore.instance;

  // ─── EmailJS credentials — fill these in after setup ─────────────────────
  // Step-by-step instructions are in the README / setup guide below
  static const _emailjsServiceId  = 'service_pvzpnen';
  static const _emailjsTemplateId = 'template_hmydmng';
  static const _emailjsPublicKey  = '4WOk5Up1oiLcU8UGH4';
  // ─────────────────────────────────────────────────────────────────────────

  static const _appName = 'Laundrify';

  /// Fires all three notification channels concurrently.
  /// Returns { inApp, email, whatsapp } success flags.
  Future<Map<String, bool>> notifyNewEmployee({
    required BuildContext context,
    required String name,
    required String email,
    required String phone,
    required String role,
    required String employeeId,
  }) async {
    final results = await Future.wait([
      _sendInAppNotification(
          name: name, email: email, role: role, employeeId: employeeId),
      _sendEmailViaEmailJS(
          name: name, email: email, phone: phone, role: role, employeeId: employeeId),
      _openWhatsApp(name: name, phone: phone, role: role, employeeId: employeeId),
    ]);
    return {'inApp': results[0], 'email': results[1], 'whatsapp': results[2]};
  }

  // ─── 1. In-App Notification ──────────────────────────────────────────────

  Future<bool> _sendInAppNotification({
    required String name,
    required String email,
    required String role,
    required String employeeId,
  }) async {
    try {
      String? userId;
      try {
        final snap = await _db
            .collection('users')
            .where('email', isEqualTo: email.trim().toLowerCase())
            .limit(1)
            .get();
        if (snap.docs.isNotEmpty) userId = snap.docs.first.id;
      } catch (_) {}

      // ignore: unused_local_variable
      final roleLabel = _roleLabel(role);
      final welcomeBody = 'Hi \$name, you have been added as a \$roleLabel (ID: \$employeeId). '
          'Sign in with this email to access your dashboard.';
      final notifData = <String, dynamic>{
        'title': '🎉 Welcome to $_appName!',
        'body': welcomeBody,
        'message': welcomeBody, // alias — notification listener reads 'message' field
        'type': 'employee_welcome',
        'role': role,
        'employeeId': employeeId,
        'isRead': false,
        'createdAt': FieldValue.serverTimestamp(),
      };

      if (userId != null) {
        notifData['userId'] = userId;
      } else {
        notifData['pendingEmail'] = email.trim().toLowerCase();
        notifData['targetGroup']  = 'pending_employee';
      }

      await _db.collection('notifications').add(notifData);
      return true;
    } catch (e) {
      debugPrint('EmployeeNotificationService._sendInAppNotification: \$e');
      return false;
    }
  }

  // ─── 2. Email via EmailJS ────────────────────────────────────────────────
  //
  // EmailJS sends email directly from Flutter using your Gmail (or any email).
  // Free plan: 200 emails/month. No domain, no backend, no extra packages.
  //
  // Template variables used (set these up in your EmailJS template):
  //   {{to_email}}     - recipient email
  //   {{to_name}}      - employee name
  //   {{role}}         - employee role
  //   {{employee_id}}  - employee ID
  //   {{phone}}        - employee phone
  //   {{app_name}}     - app name

  Future<bool> _sendEmailViaEmailJS({
    required String name,
    required String email,
    required String phone,
    required String role,
    required String employeeId,
  }) async {
    if (_emailjsServiceId == 'YOUR_SERVICE_ID' ||
        _emailjsTemplateId == 'YOUR_TEMPLATE_ID' ||
        _emailjsPublicKey == 'YOUR_PUBLIC_KEY') {
      debugPrint('EmployeeNotificationService: EmailJS credentials not set — skipping email');
      return false;
    }

    try {
      final roleLabel = _roleLabel(role);

      debugPrint('EmployeeNotificationService: sending email to \$email via EmailJS...');

      final response = await http.post(
        Uri.parse('https://api.emailjs.com/api/v1.0/email/send'),
        headers: {
          'Content-Type': 'application/json',
          'origin': 'http://localhost',
        },
        body: jsonEncode({
          'service_id':  _emailjsServiceId,
          'template_id': _emailjsTemplateId,
          'user_id':     _emailjsPublicKey,
          'template_params': {
            'to_email':    email,
            'to_name':     name,
            'role':        roleLabel,
            'employee_id': employeeId,
            'phone':       phone.isNotEmpty ? phone : 'N/A',
            'app_name':    _appName,
          },
        }),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        debugPrint('EmployeeNotificationService: ✅ email sent to \$email');
        return true;
      } else {
        debugPrint('EmployeeNotificationService: ❌ EmailJS HTTP \${response.statusCode}');
        debugPrint('  Response: \${response.body}');
        return false;
      }
    } on TimeoutException {
      debugPrint('EmployeeNotificationService: EmailJS request timed out');
      return false;
    } catch (e) {
      debugPrint('EmployeeNotificationService._sendEmailViaEmailJS: \$e');
      return false;
    }
  }

  // ─── 3. WhatsApp via wa.me ───────────────────────────────────────────────

  Future<bool> _openWhatsApp({
    required String name,
    required String phone,
    required String role,
    required String employeeId,
  }) async {
    try {
      final cleaned = phone.replaceAll(RegExp(r'[^\d+]'), '');
      if (cleaned.isEmpty) return false;

      // ignore: unused_local_variable
      final intlPhone = cleaned.startsWith('+')
          ? cleaned
          : cleaned.startsWith('91') && cleaned.length >= 12
              ? '+\$cleaned'
              : '+91\$cleaned';

      // ignore: unused_local_variable
      final roleLabel = _roleLabel(role);
      // ignore: unused_local_variable
      final message = Uri.encodeComponent(
        'Hi \$name! 👋\n\n'
        'Welcome to *\$_appName*! 🎉\n\n'
        'You have been added as a *\$roleLabel* to our team.\n\n'
        '📋 *Your Details:*\n'
        '• Employee ID: *\$employeeId*\n'
        '• Role: *\$roleLabel*\n\n'
        '📱 Download the \$_appName app and sign in with your registered email. '
        'You will be taken straight to your dashboard.\n\n'
        'Welcome aboard! 🚀',
      );

      final uri = Uri.parse('https://wa.me/\$intlPhone?text=\$message');
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri,
            mode: kIsWeb
                ? LaunchMode.platformDefault
                : LaunchMode.externalApplication);
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('EmployeeNotificationService._openWhatsApp: \$e');
      return false;
    }
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────

  String _roleLabel(String role) {
    switch (role.toLowerCase()) {
      case 'delivery': return 'Delivery Agent';
      case 'manager':  return 'Manager';
      case 'staff':    return 'Staff Member';
      case 'admin':    return 'Administrator';
      default: return role[0].toUpperCase() + role.substring(1);
    }
  }
}
